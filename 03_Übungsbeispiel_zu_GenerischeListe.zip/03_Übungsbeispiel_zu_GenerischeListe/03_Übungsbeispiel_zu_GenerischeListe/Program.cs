﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _03_Übungsbeispiel_zu_GenerischeListe
{
    class GenericList
    {
        private ListEntry firstEntry;
        private int count;

        public int Count
        {
            get { return count; }
        }

        public void Add(object data)
        {
            ListEntry newEntry = new ListEntry();
            newEntry.data = data;

            newEntry.next = firstEntry;
            firstEntry = newEntry;
            count++;
        }
        public void Ausgabe()
        {
            ListEntry current = firstEntry;

            while (current != null)
            {
                Console.WriteLine(current.data);
                current = current.next;
            }
        }
        public object Pop()
        {
            if (firstEntry == null) return null;

            object data = firstEntry.data;
            firstEntry = firstEntry.next;
            count--;
            return data;
        }

    }
    class ListEntry
    {
        public ListEntry next;
        public object data;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            GenericList meineListe = new GenericList();
            meineListe.Add("Hallo");
            meineListe.Add(345.5);
            meineListe.Add(new { name = "Dagobert", alter = 70 });
            Console.WriteLine("Alle Elemente:");
            meineListe.Ausgabe();

            Console.WriteLine("\nPop: " + meineListe.Pop());
            Console.WriteLine("Nach Pop:");
            meineListe.Ausgabe();

            Console.WriteLine("\nAnzahl: " + meineListe.Count);

            Console.ReadKey();
        }
    }
}
